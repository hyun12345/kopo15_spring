//package kr.co.uclick.repository;
//
//import java.util.List;
//
//import kr.co.uclick.entity.User;
//
//public interface UserTestRepository {
//
//	public List<User> findUserByNameLike(String name);
//	
//}
