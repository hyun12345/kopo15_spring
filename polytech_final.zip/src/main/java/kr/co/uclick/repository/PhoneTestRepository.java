//package kr.co.uclick.repository;
//
//import java.util.List;
//
//import kr.co.uclick.entity.Phone;
//
//public interface PhoneTestRepository {
//
//	public Phone findPhoneByNumber(String number);
//}
